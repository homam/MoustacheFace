//
//  main.m
//  MoustacheFace
//
//  Created by Homam Hosseini on 5/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MoustacheFaceAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MoustacheFaceAppDelegate class]));
    }
}
