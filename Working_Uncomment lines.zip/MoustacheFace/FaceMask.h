//
//  FaceMask.h
//  MoustacheFace
//
//  Created by Homam Hosseini on 5/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import<QuartzCore/QuartzCore.h>
#import "MetaCALayer.h"

typedef float (^FaceFeatureDescriptorAdjuster)(float v, CGSize featureSize, CGSize faceSize);
typedef CGRect (^FaceFeatureRectConverter)(CGRect faceRect);

@interface FaceDescriptor : NSObject

-(id)initWithWidthRatioOfFace:(float)widthRatioOfFace andXAdjuster:(FaceFeatureDescriptorAdjuster) xAdjuster andYAdjuster:(FaceFeatureDescriptorAdjuster) yAdjuster;

@property (nonatomic) float widthRatioOfFace;
@property (nonatomic, weak) MetaCALayer *featureLayer;
@property (nonatomic, strong) FaceFeatureDescriptorAdjuster xAdjuster;
@property (nonatomic, strong) FaceFeatureDescriptorAdjuster yAdjuster;
-(void)adjustLayer:(CGPoint)point faceRect:(CGRect) originalFaceRect rectConverter:(FaceFeatureRectConverter) converter;


@end

@interface FaceFeatureDescriptor : FaceDescriptor




@end
