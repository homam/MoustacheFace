//
//  FaceMask.m
//  MoustacheFace
//
//  Created by Homam Hosseini on 5/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "FaceMask.h"

@implementation FaceDescriptor

-(id)initWithWidthRatioOfFace:(float)widthRatioOfFace andXAdjuster:(FaceFeatureDescriptorAdjuster) xAdjuster andYAdjuster:(FaceFeatureDescriptorAdjuster) yAdjuster{
    self = [super init];
    self.xAdjuster = xAdjuster;
    self.yAdjuster = yAdjuster;
    self.widthRatioOfFace = widthRatioOfFace;
    return self;
}


@synthesize widthRatioOfFace = _widthRatioOfFace;
@synthesize xAdjuster = _xAdjuster;
@synthesize yAdjuster = _yAdjuster;
@synthesize featureLayer = _featureLayer;

-(void)adjustLayer:(CGPoint)point faceRect:(CGRect) originalFaceRect rectConverter:(FaceFeatureRectConverter) converter{
    [self.featureLayer metaSetWidth:originalFaceRect.size.width*self.widthRatioOfFace];
    [self.featureLayer 
             metaSetFrameLeft:self.xAdjuster(point.x,self.featureLayer.frame.size, originalFaceRect.size)
                               Bottom:self.yAdjuster(point.y,self.featureLayer.frame.size, originalFaceRect.size)];
}

@end

@implementation FaceFeatureDescriptor


-(void)adjustLayer:(CGPoint)point faceRect:(CGRect) originalFaceRect rectConverter:(FaceFeatureRectConverter) converter{
    [self.featureLayer metaSetWidth:originalFaceRect.size.width*self.widthRatioOfFace andFlip:YES];
    [self.featureLayer 
            metaSetFrameCenterX:self.xAdjuster(point.x, self.featureLayer.frame.size, originalFaceRect.size) 
                              Y:self.yAdjuster(point.y,  self.featureLayer.frame.size, originalFaceRect.size)];
    self.featureLayer.frame = converter(self.featureLayer.frame);
}

@end